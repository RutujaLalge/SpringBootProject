package com.sourabhsurve.userservice;

public enum UserRole {

    ADMIN,
    USER,
}
