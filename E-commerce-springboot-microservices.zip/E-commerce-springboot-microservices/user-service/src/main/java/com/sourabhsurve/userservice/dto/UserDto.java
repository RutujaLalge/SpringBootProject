package com.sourabhsurve.userservice.dto;

import lombok.Data;

@Data
public class UserDto {

    private Long id;

    private String Name;

    private String email;

    private String phoneNumber;

    private String password;


}
