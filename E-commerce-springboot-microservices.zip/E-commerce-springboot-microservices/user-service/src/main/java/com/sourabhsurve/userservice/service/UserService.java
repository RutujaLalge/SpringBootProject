package com.sourabhsurve.userservice.service;

import com.sourabhsurve.userservice.dto.UserDto;
import com.sourabhsurve.userservice.entity.User;

import java.util.List;

public interface UserService {

    //create
    User createUser(UserDto userDto);

    //getAll
    List<User> getAllUsers();

    //getUserById
    User getUserById(Long id);

    //updateUser
    User updateUser(Long id, UserDto userDto);

    //deleteUser
    void deleteUserById(Long id);
}
