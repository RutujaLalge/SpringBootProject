package com.sourabhsurve.userservice.service;

import com.sourabhsurve.userservice.dto.UserDto;
import com.sourabhsurve.userservice.entity.User;
import com.sourabhsurve.userservice.exception.UserNotFoundException;
import com.sourabhsurve.userservice.repository.UserRepo;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import java.util.List;


@Service
public class UserServiceImpl implements UserService{

    @Autowired
    private UserRepo userRepo;

//    @Autowired
//    PasswordEncoder passwordEncoder ;

    @Override
    public User createUser(UserDto userDto) {
        User user = new User();
        BeanUtils.copyProperties(userDto,user);
//        user.setPassword(passwordEncoder.encode(userDto.getPassword()));
        User createdUser = this.userRepo.save(user);
        return createdUser;
    }

    @Override
    public List<User> getAllUsers() {
        List<User> users = this.userRepo.findAll();
        return users;
    }

    @Override
    public User getUserById(Long id) {
        User user = this.userRepo.findById(id).orElseThrow(() ->
                new UserNotFoundException("User with id " + id + " not found"));

        return user;
    }

    @Override
    public User updateUser(Long id, UserDto userDto) {
        User existingUser = this.userRepo.findById(id).orElseThrow(() ->
                new UserNotFoundException("User with id " + id + " not found"));

        existingUser.setName(userDto.getName());
        existingUser.setEmail(userDto.getEmail());
        existingUser.setPhoneNumber(userDto.getPhoneNumber());
        existingUser.setPassword(userDto.getPassword());
        User updatedUser = this.userRepo.save(existingUser);
        return updatedUser;
    }

    @Override
    public void deleteUserById(Long id) {

        User user = this.userRepo.findById(id).orElseThrow(() ->
                new UserNotFoundException("User with id " + id + " not found"));

        this.userRepo.delete(user);

    }
}
