package com.sourabhsurve.categoryservice.service;

import com.sourabhsurve.categoryservice.dto.CategoryDto;
import com.sourabhsurve.categoryservice.entity.Category;

import java.util.List;

public interface CategoryService {

    //create
    Category createCategory(CategoryDto categoryDTO);

    //getById
    Category getCategoryById(Long id);

    //getAll
    List<Category> getAllCategories();

    //update
    Category updateCategory(Long id, CategoryDto categoryDTO);

    //delete
    void deleteCategory(Long id);

}
