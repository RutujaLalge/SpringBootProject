package com.sourabhsurve.cartservice.service;

import com.sourabhsurve.cartservice.dto.CartDto;
import com.sourabhsurve.cartservice.entity.Cart;

import java.util.List;

public interface CartService {

    //create
    Cart createCart(CartDto cartDTO);

    //update
    Cart updateCart(Long id, CartDto cartDTO);

    //getById
    Cart getCartById(Long id);

    //getAll
    List<Cart> getAllCarts();

    //delete
    void deleteCart(Long id);

}