package com.sourabhsurve.cartservice.controller;

import com.sourabhsurve.cartservice.dto.CartDto;
import com.sourabhsurve.cartservice.entity.Cart;
import com.sourabhsurve.cartservice.service.CartService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/carts")
public class CartController {

        @Autowired
        private CartService cartService;

        @PostMapping("/create")
        public ResponseEntity<Cart> createCart(@RequestBody CartDto cartDTO) {
            Cart createdCart = cartService.createCart(cartDTO);
            return new ResponseEntity<>(createdCart, HttpStatus.CREATED);
        }

        @GetMapping("get/{id}")
        public ResponseEntity<Cart> getCartById(@PathVariable Long id) {
            Cart cart = cartService.getCartById(id);
            return new ResponseEntity<>(cart, HttpStatus.OK);
        }

        @GetMapping("/getAll")
        public ResponseEntity<List<Cart>> getAllCarts() {
            List<Cart> carts = cartService.getAllCarts();
            return new ResponseEntity<>(carts, HttpStatus.OK);
        }

        @PutMapping("update/{id}")
        public ResponseEntity<Cart> updateCart(@PathVariable Long id, @RequestBody CartDto cartDTO) {
            Cart updatedCart = cartService.updateCart(id, cartDTO);
            return new ResponseEntity<>(updatedCart, HttpStatus.OK);
        }

        @DeleteMapping("delete/{id}")
        public ResponseEntity<Void> deleteCart(@PathVariable Long id) {
            cartService.deleteCart(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }
}
