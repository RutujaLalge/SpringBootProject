package com.sourabhsurve.cartservice.dto;

import lombok.Data;

@Data
public class CartDto {

    private Long id;


    private Long price;


    private Long quantity;

}
