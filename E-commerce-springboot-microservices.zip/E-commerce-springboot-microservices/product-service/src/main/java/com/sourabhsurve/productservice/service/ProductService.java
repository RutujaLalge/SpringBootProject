package com.sourabhsurve.productservice.service;

import com.sourabhsurve.productservice.dto.ProductDto;
import com.sourabhsurve.productservice.entity.Product;

import java.util.List;

public interface ProductService {

    //create
    Product createProduct(ProductDto productDto);

    //getAll
    List<Product> getAllProducts();

    //getById
    Product getProductById(Long id);

    //update
    Product updateProduct(Long id, ProductDto productDto);

    //delete
    void deleteProductById(Long id);
}
