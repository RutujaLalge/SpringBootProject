package com.sourabhsurve.productservice.service;

import com.sourabhsurve.productservice.dto.ProductDto;
import com.sourabhsurve.productservice.entity.Product;
import com.sourabhsurve.productservice.exception.ProductNotFoundException;
import com.sourabhsurve.productservice.repository.ProductRepo;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepo productRepo;

//    @Autowired
//    private CategoryRepository categoryRepository;

    @Override
    public Product createProduct(ProductDto productDto) {
        Product product = new Product();
        BeanUtils.copyProperties(productDto, product);
        Product createdProduct = this.productRepo.save(product);
        return createdProduct;
    }

    @Override
    public List<Product> getAllProducts() {
        List<Product> products = this.productRepo.findAll();
        return products;
    }

    @Override
    public Product getProductById(Long id) {
        Product product = this.productRepo.findById(id)
                .orElseThrow(() -> new ProductNotFoundException("Product with id " + id + " not found"));
        return product;
    }

    @Override
    public Product updateProduct(Long id, ProductDto productDto) {
        Product existingProduct = this.productRepo.findById(id)
                .orElseThrow(() -> new ProductNotFoundException("Product with id " + id + " not found"));
        existingProduct.setDescription(productDto.getDescription());
        existingProduct.setName(productDto.getName());
        existingProduct.setPrice(productDto.getPrice());
        existingProduct.setImg(productDto.getImg());
        Product updatedProduct = this.productRepo.save(existingProduct);
        return updatedProduct;
    }

    @Override
    public void deleteProductById(Long id) {
        Product product = this.productRepo.findById(id)
                .orElseThrow(() -> new ProductNotFoundException("Product with id " + id + " not found"));
        productRepo.delete(product);
    }

}
