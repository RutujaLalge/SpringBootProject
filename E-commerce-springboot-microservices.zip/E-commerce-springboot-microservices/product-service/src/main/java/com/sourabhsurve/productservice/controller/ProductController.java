package com.sourabhsurve.productservice.controller;

import com.sourabhsurve.productservice.dto.ProductDto;
import com.sourabhsurve.productservice.entity.Product;
import com.sourabhsurve.productservice.service.ProductService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/products")
public class ProductController {

    @Autowired
    private ProductService productService;

    @PostMapping("/create")
    public ResponseEntity<Product> createProduct(@Valid @RequestBody ProductDto productDto) {
        Product createdProduct = this.productService.createProduct(productDto);
        return ResponseEntity.status(HttpStatus.CREATED).body(createdProduct);
    }

    @GetMapping("/getAll")
    public ResponseEntity<List<Product>> getAllProducts() {
        List<Product> products = this.productService.getAllProducts();
        return ResponseEntity.ok(products);
    }

    @GetMapping("get/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable Long id) {

            Product product = this.productService.getProductById(id);
            return ResponseEntity.ok(product);

    }

    @PutMapping("update/{id}")
    public ResponseEntity<Product> updateProduct(@PathVariable Long id, @Valid @RequestBody ProductDto productDto) {

            Product updatedProduct = this.productService.updateProduct(id, productDto);
            return ResponseEntity.ok(updatedProduct);

    }

    @DeleteMapping("delete/{id}")
    public ResponseEntity<Void> deleteProductById(@PathVariable Long id) {

            this.productService.deleteProductById(id);
            return ResponseEntity.noContent().build();

    }
}
