package com.sourabhsurve.orderservice.dto;

import com.sourabhsurve.orderservice.helper.OrderStatus;
import lombok.Data;

import java.util.Date;
import java.util.UUID;
@Data
public class OrderDto {

    private Long id;

    private String orderDescription;


    private Date date;


    private Long amount;


    private String address;


    private OrderStatus orderStatus;


    private Long totalAmount;


    private Long discount;


    private UUID trackingId;
}
