package com.sourabhsurve.orderservice.service;

import com.sourabhsurve.orderservice.dto.OrderDto;
import com.sourabhsurve.orderservice.entity.Order;

import java.util.List;

public interface OrderService {

    //create
    Order createOrder(OrderDto orderDto);

    //getAll
    List<Order> getAllOrders();

    //getOrderById
    Order getOrderById(Long id);

    //updateOrder
    Order updateOrder(Long id, OrderDto orderDto);

    //deleteOrder
    void deleteOrderById(Long id);
}
