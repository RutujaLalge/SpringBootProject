package com.sourabhsurve.orderservice.helper;

public enum OrderStatus {

    Pending,

    Placed,

    Shipped,

    Delivered
}
